const fs = require("fs")
const express = require('express')
const app = express()
const path = require('path')
const PORT = 3000


app.use(express.static(__dirname +'/SubDirectories'))



app.get('/', function(req,res){
    res.sendFile(path.join(__dirname +'/index.html'))
})


const filenames = fs.readdirSync(__dirname + "/SubDirectories");  

let folders =[]
let files =[]


filenames.forEach(element => {
    if (element.indexOf('.') == -1){
        folders.push(element)
    } else {
        files.push(element)
    }
});


const seperation = {folders, files}
console.log(seperation)

app.get('/fetch', function(req,res){
    res.send(JSON.stringify(seperation,null,5))
})

app.get('/search', function(req,res){
    let input_value = req.query.input_value
    console.log(input_value)
    let search_results =[]
    files.forEach(element => {
        if (element.indexOf(input_value) <= 1){
            search_results.push(element)
        } 
    });
    console.log(search_results)
    res.send(JSON.stringify(search_results,null,5))
})



app.listen(PORT, function () {
    console.log("start serwera na porcie : " + PORT)
})